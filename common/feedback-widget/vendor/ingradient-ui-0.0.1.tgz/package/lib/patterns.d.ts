import * as styled_components_dist_types from 'styled-components/dist/types';
import * as styled_components from 'styled-components';
import * as React from 'react';
import React__default, { ReactNode } from 'react';
import * as react_jsx_runtime from 'react/jsx-runtime';
import { b as DrawingObject, c as DrawingPreview, C as CartesianSeries, P as PieDatum, G as GridSelectionAction } from './types-CKU1Jsar.js';

declare const AppShell: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<React.DetailedHTMLProps<React.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>> & string;
declare const PageHeader: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<React.DetailedHTMLProps<React.HTMLAttributes<HTMLElement>, HTMLElement>, never>> & string;
declare const PageHeaderRow: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<React.DetailedHTMLProps<React.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>> & string;
declare const PageTitleBlock: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<React.DetailedHTMLProps<React.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>> & string;
declare const PageTitle: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<React.DetailedHTMLProps<React.HTMLAttributes<HTMLHeadingElement>, HTMLHeadingElement>, never>> & string;
declare const PageSubtitle: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<React.DetailedHTMLProps<React.HTMLAttributes<HTMLParagraphElement>, HTMLParagraphElement>, never>> & string;
declare const PageContent: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<React.DetailedHTMLProps<React.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>> & string;
declare const Panel: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<React.DetailedHTMLProps<React.HTMLAttributes<HTMLElement>, HTMLElement>, never>> & string;
declare const PanelHeader: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<React.DetailedHTMLProps<React.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>> & string;
declare const PanelTitle: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<React.DetailedHTMLProps<React.HTMLAttributes<HTMLHeadingElement>, HTMLHeadingElement>, never>> & string;
declare const PanelHint: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<React.DetailedHTMLProps<React.HTMLAttributes<HTMLSpanElement>, HTMLSpanElement>, never>> & string;
declare const SectionTitle: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<React.DetailedHTMLProps<React.HTMLAttributes<HTMLHeadingElement>, HTMLHeadingElement>, never>> & string;
declare const Toolbar: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<React.DetailedHTMLProps<React.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>> & string;
declare const FilterBar: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<Omit<styled_components.FastOmit<React.DetailedHTMLProps<React.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>, "ref"> & {
    ref?: ((instance: HTMLDivElement | null) => void | React.DO_NOT_USE_OR_YOU_WILL_BE_FIRED_CALLBACK_REF_RETURN_VALUES[keyof React.DO_NOT_USE_OR_YOU_WILL_BE_FIRED_CALLBACK_REF_RETURN_VALUES]) | React.RefObject<HTMLDivElement> | null | undefined;
}, never>> & string;
declare const FormSection: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<Omit<styled_components.FastOmit<React.DetailedHTMLProps<React.HTMLAttributes<HTMLElement>, HTMLElement>, never>, "ref"> & {
    ref?: ((instance: HTMLElement | null) => void | React.DO_NOT_USE_OR_YOU_WILL_BE_FIRED_CALLBACK_REF_RETURN_VALUES[keyof React.DO_NOT_USE_OR_YOU_WILL_BE_FIRED_CALLBACK_REF_RETURN_VALUES]) | React.RefObject<HTMLElement> | null | undefined;
}, never>> & string;
declare const FieldGroup: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<React.DetailedHTMLProps<React.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>> & string;
declare const FieldLabel: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<React.DetailedHTMLProps<React.LabelHTMLAttributes<HTMLLabelElement>, HTMLLabelElement>, never>> & string;
declare const FieldHint: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<React.DetailedHTMLProps<React.HTMLAttributes<HTMLSpanElement>, HTMLSpanElement>, never>> & string;

declare function SplitLayout({ sidebar, content, inspector, sidebarWidth, inspectorWidth, }: {
    sidebar?: React__default.ReactNode;
    content: React__default.ReactNode;
    inspector?: React__default.ReactNode;
    sidebarWidth?: string;
    inspectorWidth?: string;
}): react_jsx_runtime.JSX.Element;
declare const DashboardGrid: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<React__default.DetailedHTMLProps<React__default.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>> & string;
declare const ListDetailLayout: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<React__default.DetailedHTMLProps<React__default.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>> & string;
declare const SettingsShell: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<React__default.DetailedHTMLProps<React__default.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>> & string;
declare const InspectorLayout: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<React__default.DetailedHTMLProps<React__default.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>> & string;

declare const SidebarNav: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<React.DetailedHTMLProps<React.HTMLAttributes<HTMLElement>, HTMLElement>, never>> & string;
declare const AppSidebar: styled_components_dist_types.IStyledComponentBase<"web", styled_components_dist_types.Substitute<React.DetailedHTMLProps<React.HTMLAttributes<HTMLElement>, HTMLElement>, {
    $width?: number | string;
}>> & string;
declare const SidebarSection: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<React.DetailedHTMLProps<React.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>> & string;
declare const SidebarFooter: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<React.DetailedHTMLProps<React.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>> & string;
declare const TopBar: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<React.DetailedHTMLProps<React.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>> & string;
declare const MobileNavDrawer: styled_components_dist_types.IStyledComponentBase<"web", styled_components_dist_types.Substitute<React.DetailedHTMLProps<React.HTMLAttributes<HTMLElement>, HTMLElement>, {
    $open?: boolean;
}>> & string;

interface SidebarShellItem {
    key: string;
    title: string;
    label: string;
    icon: React__default.ReactNode;
    /** Route path. Passed as `to` to `linkComponent`, or as `href` to plain `<a>`. */
    to?: string;
    /** Component used for the clickable row. Use react-router's NavLink for active-aware items.
     *  Default: plain `<a>`. Active styling (`.active` / `aria-current="page"`) stays on the shell. */
    linkComponent?: React__default.ElementType;
    /** Optional badge (e.g. NotificationBadge). Wraps the icon. */
    badge?: React__default.ReactNode;
    /** Sub-items 가 있으면 row 는 expandable button 으로 렌더 (link 대신). 펼침 시 children 노출. */
    children?: SidebarShellItem[];
}
interface SidebarShellAction {
    key: string;
    title: string;
    label: string;
    icon: React__default.ReactNode;
    onClick?: (event: React__default.MouseEvent<HTMLButtonElement>) => void;
    badge?: React__default.ReactNode;
}
interface SidebarShellProps {
    expanded: boolean;
    onToggleExpanded?: () => void;
    width?: {
        expanded?: number;
        collapsed?: number;
    };
    brand?: React__default.ReactNode;
    topAction?: React__default.ReactNode;
    items?: SidebarShellItem[];
    actions?: SidebarShellAction[];
    /** items 외 자유 body 컨텐츠. rich 한 nav (Projects / Conversations / Jobs 등) 를 가진 caller 가
     *  items 모델 (icon + label) 대신 임의 React 노드를 body 에 삽입할 때 사용. */
    children?: React__default.ReactNode;
    /** `aria-label` on the inner `<nav>` — must be unique when multiple sidebars
     *  share a page (a11y landmark-unique). Default `"Sidebar"`. */
    navLabel?: string;
    className?: string;
}
declare function SidebarShell({ expanded, onToggleExpanded, width, brand, topAction, items, actions, children, navLabel, className, }: SidebarShellProps): react_jsx_runtime.JSX.Element;

interface MediaDialogShellProps {
    /** Backdrop 클릭 시 호출. 없으면 backdrop click 이 무시됩니다. */
    onClose?: () => void;
    /** 메인 영역 — 보통 toolbar + canvas 같은 column layout. */
    main: React__default.ReactNode;
    /** 우측 사이드바 (optional). 없으면 main 만 전체 너비. */
    sidebar?: React__default.ReactNode;
    /** 사이드바 width 픽셀. caller 가 resize state 관리. default 320 */
    sidebarWidth?: number;
    /** 사이드바 resize handle mousedown — caller 가 width 계산 + state set. */
    onSidebarResize?: (event: React__default.MouseEvent<HTMLDivElement>) => void;
    /** Content box width override (default 95vw, mobile 100vw). */
    width?: string;
    /** Content box height override (default calc(100vh - 80px), mobile 100dvh). */
    height?: string;
    /** Absolute layer 자식 (ContextMenu 등) — ModalContent sibling 으로 렌더. */
    overlay?: React__default.ReactNode;
    /** Dialogs / Confirmations sibling — Overlay 외 동일 z-layer. */
    extras?: React__default.ReactNode;
    /** Content box 기준 오른쪽 상단 floating controls. */
    topRight?: React__default.ReactNode;
    /** 추가 핸들러 forward (touch swipe, context menu 등). */
    onContextMenu?: (event: React__default.MouseEvent<HTMLDivElement>) => void;
    onTouchStart?: (event: React__default.TouchEvent<HTMLDivElement>) => void;
    onTouchEnd?: (event: React__default.TouchEvent<HTMLDivElement>) => void;
    /** 추가 className 을 Content 박스에 부여. */
    className?: string;
    /** ARIA dialog label */
    ariaLabel?: string;
    /** Outer container position. `'fixed'` (default) covers the viewport — production
     *  modal usage. `'absolute'` confines the shell to the nearest positioned ancestor
     *  — Storybook in-card demos, or Workspace-relative embedded usage. */
    positioning?: 'fixed' | 'absolute';
}
declare function MediaDialogShell({ onClose, main, sidebar, sidebarWidth, onSidebarResize, width, height, overlay, extras, topRight, onContextMenu, onTouchStart, onTouchEnd, className, ariaLabel, positioning, }: MediaDialogShellProps): react_jsx_runtime.JSX.Element;

interface DrawingLayerProps {
    objects: DrawingObject[];
    selectedId?: string | null;
    drawingPreview?: DrawingPreview | null;
    showHandles?: boolean;
    showLabels?: boolean;
    showCrosshair?: boolean;
    cursorX?: number;
    cursorY?: number;
    /** Container pixel width — enables uniform stroke/handle rendering */
    containerWidth?: number;
    /** Container pixel height — enables uniform stroke/handle rendering */
    containerHeight?: number;
    /** Color for the drawing preview (defaults to `var(--ig-color-accent)`). */
    previewColor?: string;
    /** Color for the crosshair lines (defaults to `var(--ig-color-white-30)`). */
    crosshairColor?: string;
    /** Current zoom level — used to keep stroke width and label size constant regardless of zoom */
    zoom?: number;
}
declare function DrawingLayer({ objects, selectedId, drawingPreview, showHandles, showLabels, showCrosshair, cursorX, cursorY, containerWidth, containerHeight, previewColor, crosshairColor, zoom: zoomProp, }: DrawingLayerProps): react_jsx_runtime.JSX.Element;

interface LabelingCanvasProps {
    /** Image source. */
    imageUrl?: string | null;
    alt: string;
    /** Image aspect ratio (width / height). Controlled — caller updates on load. */
    imageAspect: number;
    /** Called when `<img>` natural dimensions load. caller updates `imageAspect`. */
    onImageLoad?: (naturalWidth: number, naturalHeight: number) => void;
    onImageError?: () => void;
    /** Zoom + pan (controlled, from useZoomPan). */
    zoom: number;
    pan: {
        x: number;
        y: number;
    };
    /** Drawing data (from useDrawingCanvas + state). */
    objects: DrawingObject[];
    preview?: DrawingPreview | null;
    selectedId?: string | null;
    showHandles?: boolean;
    showLabels?: boolean;
    /** Drawing preview color (e.g. selected class color). */
    previewColor?: string;
    /** Capture layer mouse handlers (보통 useCanvasMouse 결과). */
    mouseHandlers: {
        onMouseDown: (event: React__default.MouseEvent<HTMLDivElement>) => void;
        onMouseMove: (event: React__default.MouseEvent<HTMLDivElement>) => void;
        onMouseUp: (event: React__default.MouseEvent<HTMLDivElement>) => void;
        onMouseLeave: () => void;
    };
    /** Capture layer CSS cursor. */
    cursor: React__default.CSSProperties['cursor'];
    /** Crosshair display config. null/undefined = 숨김. */
    crosshair?: {
        x: number;
        y: number;
        color?: string;
    } | null;
    /** Image area 안 추가 overlays — DrawingLayer 보다 *위에* 렌더되어 caller 가
     *  SAM mask / IsoLine / Modulation 등 자유 layer 추가 가능. */
    overlays?: React__default.ReactNode;
    /** Image area 안 + DrawingLayer 보다 *아래에* 렌더되는 underlay — 예: ArchivedOverlay. */
    underlays?: React__default.ReactNode;
    /** Wrap 안 absolute floating UI (HiResPill / PatternTabBar / Hint / FullscreenBtn 등). */
    floatingOverlays?: React__default.ReactNode;
    /** Image area ref (hit-test 계산용 — 보통 useCanvasMouse 의 containerRef 와 동일). */
    imageAreaRef?: React__default.Ref<HTMLDivElement>;
    /** 외부 wrap ref. */
    wrapRef?: React__default.Ref<HTMLDivElement>;
    /** Wheel handler — 마우스 휠로 zoom (보통 useZoomPan().handleWheel).
     *  Pattern 이 내부에서 `addEventListener('wheel', ..., { passive: false })` 로
     *  첨부하여 React 의 passive 기본값으로 인한 `preventDefault()` 실패 회피. */
    onWheel?: (event: WheelEvent) => void;
    className?: string;
}
declare function LabelingCanvas({ imageUrl, alt, imageAspect, onImageLoad, onImageError, zoom, pan, objects, preview, selectedId, showHandles, showLabels, previewColor, mouseHandlers, cursor, crosshair, overlays, underlays, floatingOverlays, imageAreaRef, wrapRef, onWheel, className, }: LabelingCanvasProps): react_jsx_runtime.JSX.Element;

interface ColorInputRowProps {
    value: string;
    onChange?: (hex: string) => void;
    onRandomize?: () => void;
    randomLabel?: string;
    ariaLabel?: string;
    disabled?: boolean;
}
declare function ColorInputRow({ value, onChange, onRandomize, randomLabel, ariaLabel, disabled, }: ColorInputRowProps): react_jsx_runtime.JSX.Element;

type SettingsSectionTone = 'default' | 'danger';
interface SettingsSectionProps {
    title?: string;
    children: ReactNode;
    className?: string;
    tone?: SettingsSectionTone;
}
declare function SettingsSection({ title, children, className, tone }: SettingsSectionProps): react_jsx_runtime.JSX.Element;

interface SettingsRowProps {
    label?: ReactNode;
    control?: ReactNode;
    children?: ReactNode;
    asLabel?: boolean;
    htmlFor?: string;
    className?: string;
}
declare function SettingsRow({ label, control, children, asLabel, htmlFor, className }: SettingsRowProps): react_jsx_runtime.JSX.Element;

type AutoSaveState = 'idle' | 'pending' | 'saving' | 'saved' | 'error';
interface AutoSaveStatusProps {
    /** form 의 현재 저장 상태 */
    state: AutoSaveState;
    /** error 상태일 때 표시할 메시지 (없으면 fallback) */
    errorMessage?: string | null;
    /** 추가 컨디션: editing 권한 없을 시 read-only 메시지 */
    readOnly?: boolean;
    /** 추가 컨디션: 값 유효성 실패 (e.g. 이름 빈 값) */
    invalid?: boolean;
    invalidMessage?: string;
    readOnlyMessage?: string;
    idleMessage?: string;
    pendingMessage?: string;
    savingMessage?: string;
    savedMessage?: string;
    fallbackErrorMessage?: string;
    className?: string;
}
declare function AutoSaveStatus({ state, errorMessage, readOnly, invalid, invalidMessage, readOnlyMessage, idleMessage, pendingMessage, savingMessage, savedMessage, fallbackErrorMessage, className, }: AutoSaveStatusProps): react_jsx_runtime.JSX.Element;

interface SortOption {
    value: string;
    label: string;
}
interface SortPopoverTriggerProps {
    label?: React__default.ReactNode;
    icon?: React__default.ReactNode;
    iconOnly?: boolean;
    options: SortOption[];
    value: string;
    onChange: (value: string) => void;
    defaultOpen?: boolean;
    className?: string;
}
declare function SortPopoverTrigger({ label, icon, iconOnly, options, value, onChange, defaultOpen, className, }: SortPopoverTriggerProps): react_jsx_runtime.JSX.Element;

interface FilterSectionProps {
    title: React__default.ReactNode;
    actions?: React__default.ReactNode;
    children: React__default.ReactNode;
    className?: string;
}
declare function FilterSection({ title, actions, children, className }: FilterSectionProps): react_jsx_runtime.JSX.Element;

interface FilterSearchableItem {
    id: string;
    label: string;
    color?: string;
}
interface FilterSearchableListProps {
    placeholder?: string;
    items: FilterSearchableItem[];
    selectedIds: Set<string>;
    onToggle: (id: string, checked: boolean) => void;
    emptyMessage?: string;
    className?: string;
}
declare function FilterSearchableList({ placeholder, items, selectedIds, onToggle, emptyMessage, className, }: FilterSearchableListProps): react_jsx_runtime.JSX.Element;

type DatasetTaskType = 'object_detection' | 'classification' | 'segmentation' | 'point';
interface DatasetTaskOption {
    value: DatasetTaskType;
    label: string;
    disabled?: boolean;
}
interface AddDatasetClassOption {
    id: string;
    name: string;
    color: string;
}
interface AddDatasetModalProps {
    open: boolean;
    onClose: () => void;
    onSubmit: (payload: {
        name: string;
        taskType: DatasetTaskType;
        classIds: string[];
    }) => void;
    classes: AddDatasetClassOption[];
    /** task 타입 옵션 — 미지정 시 기본(classification/object_detection/segmentation/point). */
    taskOptions?: DatasetTaskOption[];
    initialName?: string;
    initialTaskType?: DatasetTaskType;
    initialClassIds?: string[];
    submitting?: boolean;
}
declare function AddDatasetModal({ open, onClose, onSubmit, classes, taskOptions, initialName, initialTaskType, initialClassIds, submitting, }: AddDatasetModalProps): react_jsx_runtime.JSX.Element | null;

interface AnnotationBoundingBox {
    id: string;
    label?: string;
    color: string;
    /** Normalized 0~1 coordinates (left / top / width / height) */
    x: number;
    y: number;
    width: number;
    height: number;
}
interface AnnotationPolygon {
    id: string;
    label?: string;
    color: string;
    /** Normalized 0~1 points (relative to image) */
    points: {
        x: number;
        y: number;
    }[];
    fillOpacity?: number;
}
interface InspectorPoint {
    id: string;
    label?: string;
    color: string;
    /** Normalized 0~1 coordinates */
    x: number;
    y: number;
}
interface ImageInspectorCanvasProps {
    imageUrl: string;
    imageAlt?: string;
    /** Display-only bounding boxes (normalized). */
    boxes?: AnnotationBoundingBox[];
    /** Display-only points (normalized). */
    points?: InspectorPoint[];
    /** Max zoom factor (default 8). */
    maxZoom?: number;
    /** Show label chips on boxes (default true). */
    showLabels?: boolean;
    /** Show floating zoom-in / zoom-out IconButtons at top-right (default true). */
    showZoomControls?: boolean;
    /** When provided, renders a close `X` IconButton next to zoom controls. */
    onClose?: () => void;
    className?: string;
}
/**
 * Inspector-mode wrapper around `LabelingCanvas`.
 *
 * Provides zoom + pan + cursor-only mouse handling for read-only annotation
 * display. Optionally renders floating top-right controls (zoom in/out + close)
 * matching platform 의 `TopRightFloatingControls`.
 */
declare function ImageInspectorCanvas({ imageUrl, imageAlt, boxes, points, maxZoom, showLabels, showZoomControls, onClose, className, }: ImageInspectorCanvasProps): react_jsx_runtime.JSX.Element;

interface DateRangeFieldProps {
    from: string;
    to: string;
    onChange: (next: {
        from: string;
        to: string;
    }) => void;
    fromPlaceholder?: string;
    toPlaceholder?: string;
    disabled?: boolean;
    className?: string;
}
declare function DateRangeField({ from, to, onChange, fromPlaceholder, toPlaceholder, disabled, className, }: DateRangeFieldProps): react_jsx_runtime.JSX.Element;

interface CheckboxGroupItem {
    id: string;
    label: string;
    color?: string;
}
interface CheckboxGroupProps {
    items: CheckboxGroupItem[];
    selectedIds: Set<string>;
    onChange: (next: Set<string>) => void;
    maxHeight?: number;
    showSelectAll?: boolean;
}
declare function CheckboxGroup({ items, selectedIds, onChange, maxHeight, showSelectAll, }: CheckboxGroupProps): react_jsx_runtime.JSX.Element;

interface ChipGroupItem {
    id: string;
    label: string;
    color?: string;
}
interface ChipGroupProps {
    items: ChipGroupItem[];
    maxVisible?: number;
    onItemClick?: (id: string) => void;
    className?: string;
}
declare function ChipGroup({ items, maxVisible, onItemClick, className }: ChipGroupProps): react_jsx_runtime.JSX.Element;

interface PagePrimaryHeaderProps {
    title: React__default.ReactNode;
    subtitle?: React__default.ReactNode;
    /** 기본 우측 슬롯 — 보통 project name 등의 컨텍스트 문자열. */
    rightSlot?: React__default.ReactNode;
    className?: string;
}
/**
 * Platform 페이지 (Catalog / ClassManage 등) 의 hero-style top header.
 * 좌측: PageTitleBlock (title + subtitle, 2xl 타이포)
 * 우측: rightSlot (project name 등)
 */
declare function PagePrimaryHeader({ title, subtitle, rightSlot, className, }: PagePrimaryHeaderProps): react_jsx_runtime.JSX.Element;

declare function ChartContainer({ title, description, height, loading, empty, emptyMessage, legend, headerExtra, children, }: {
    title?: string;
    description?: string;
    height?: number;
    loading?: boolean;
    empty?: boolean;
    emptyMessage?: string;
    legend?: React__default.ReactNode;
    headerExtra?: React__default.ReactNode;
    children: React__default.ReactNode;
}): react_jsx_runtime.JSX.Element;

declare function BarChartCard<T extends Record<string, string | number>>({ title, description, data, series, xKey, height, loading, emptyMessage, layout, stacked, getCellColor, tooltipContent, headerExtra, }: {
    title?: string;
    description?: string;
    data: T[];
    series: CartesianSeries[];
    xKey: keyof T & string;
    height?: number;
    loading?: boolean;
    /** Message rendered when `data` is empty. Forwarded to ChartContainer. */
    emptyMessage?: string;
    /** 'horizontal' (default) = vertical bars / X axis at bottom. 'vertical' = horizontal bars / category on Y axis. */
    layout?: 'horizontal' | 'vertical';
    /** When true, all series share `stackId='a'` to render as a stacked bar chart. */
    stacked?: boolean;
    /** Per-row color override (only applied when `series.length === 1`). */
    getCellColor?: (datum: T, index: number) => string;
    /** Custom tooltip ReactElement passed to `<Tooltip content={...} />`. */
    tooltipContent?: React__default.ReactElement;
    /** Header right-slot rendered next to the legend (e.g. dropdowns, status pills). */
    headerExtra?: React__default.ReactNode;
}): react_jsx_runtime.JSX.Element;

declare function LineChartCard<T extends Record<string, string | number>>({ title, description, data, series, xKey, height, loading, emptyMessage, onPointClick, secondaryAxisKeys, tooltipContent, headerExtra, }: {
    title?: string;
    description?: string;
    data: T[];
    series: CartesianSeries[];
    xKey: keyof T & string;
    height?: number;
    loading?: boolean;
    emptyMessage?: string;
    onPointClick?: (entry: T, index: number) => void;
    /** Series keys that should bind to a right-side secondary Y-axis. Triggers dual-axis layout. */
    secondaryAxisKeys?: string[];
    tooltipContent?: React__default.ReactElement;
    headerExtra?: React__default.ReactNode;
}): react_jsx_runtime.JSX.Element;

declare function PieChartCard({ title, description, data, height, loading, emptyMessage, innerRadius, outerRadius, paddingAngle, separator, labelRender, tooltipContent, headerExtra, }: {
    title?: string;
    description?: string;
    data: PieDatum[];
    height?: number;
    loading?: boolean;
    emptyMessage?: string;
    /** Inner radius of the donut. Set to 0 for a full pie. Default 60. */
    innerRadius?: number;
    /** Outer radius. Default 90. */
    outerRadius?: number;
    /** Padding angle (degrees) between slices. Default 0 keeps slices flush. */
    paddingAngle?: number;
    /** Slice separator. `subtle` keeps adjacent colors readable without creating gaps. */
    separator?: 'none' | 'subtle';
    /** Slice label renderer. `pct` is value/total in [0,1]. */
    labelRender?: (entry: PieDatum, pct: number) => React__default.ReactNode;
    tooltipContent?: React__default.ReactElement;
    headerExtra?: React__default.ReactNode;
}): react_jsx_runtime.JSX.Element;

interface AnnotationOverlayBbox {
    /** Optional — undefined classId falls back to `defaultColor` and is excluded from
     *  `selectedClassId` filtering. */
    classId?: string;
    /** Normalized [0, 1] coordinates in the original image space. */
    x: number;
    y: number;
    w: number;
    h: number;
}
interface AnnotationOverlayPoint {
    classId?: string;
    /** Normalized [0, 1] coordinates in the original image space. */
    x: number;
    y: number;
}
interface AnnotationOverlayProps {
    bboxes?: AnnotationOverlayBbox[] | null;
    points?: AnnotationOverlayPoint[] | null;
    /** Resolves classId → color hex. Returns undefined to fall back to `defaultColor`.
     *  Called with undefined when an annotation has no classId. */
    getColor: (classId: string | undefined) => string | undefined;
    /** Fallback color when `getColor` returns undefined. Default `var(--ig-color-accent)`. */
    defaultColor?: string;
    /** Filter — only render annotations matching this classId. Omit/null = render all. */
    selectedClassId?: string | null;
    /** Original image dimensions — used to compute the `object-fit: cover` viewBox so
     *  bboxes line up with the cropped thumbnail. */
    imageWidth: number | null | undefined;
    imageHeight: number | null | undefined;
    /** Tint bbox fill at this opacity (0~1). Default 0 = stroke-only (edge style). */
    fillOpacity?: number;
    /** Draw a double white/dark outline around bbox/point for thumbnail readability.
     *  Default false. platform 의 catalog 썸네일 패턴은 true. */
    emphasize?: boolean;
    className?: string;
}
declare function AnnotationOverlay({ bboxes, points, getColor, defaultColor, selectedClassId, imageWidth, imageHeight, fillOpacity, emphasize, className, }: AnnotationOverlayProps): react_jsx_runtime.JSX.Element | null;

interface CommentThreadProps {
    children: React__default.ReactNode;
    className?: string;
}
declare function CommentThread({ children, className }: CommentThreadProps): react_jsx_runtime.JSX.Element;

interface ImageGridLayout {
    minWidth?: number;
    columns?: number;
    gap?: number;
}
interface ImageGridProps<T extends {
    id: string;
}> {
    items: T[];
    getThumbnailUrl: (item: T) => string;
    layout?: ImageGridLayout;
    /** 그리드 둘레에 var(--ig-space-7) 패딩 래퍼(스크롤 영역 안). simon GalleryImageGrid `padded` 대응. */
    padded?: boolean;
    onItemClick?: (item: T, index: number, event: React__default.MouseEvent) => void;
    onItemDoubleClick?: (item: T, index: number, event: React__default.MouseEvent) => void;
    selectedIds?: Set<string>;
    onSelectionChange?: (action: GridSelectionAction, id: string, index: number) => void;
    onDragStart?: (item: T, index: number, event: React__default.DragEvent) => void;
    onContextMenu?: (item: T, index: number, event: React__default.MouseEvent) => void;
    onCellMouseEnter?: (item: T, index: number, event: React__default.MouseEvent) => void;
    onCellMouseLeave?: (item: T, index: number) => void;
    highlightedId?: string | null;
    renderCellOverlay?: (item: T, index: number) => React__default.ReactNode;
    renderCellFooter?: (item: T, index: number) => React__default.ReactNode;
    renderCellTopRight?: (item: T, index: number) => React__default.ReactNode;
    hasMore?: boolean;
    onLoadMore?: () => void;
    isLoadingMore?: boolean;
}
declare function ImageGrid<T extends {
    id: string;
}>(props: ImageGridProps<T>): react_jsx_runtime.JSX.Element;

interface ImageGridCellProps<T extends {
    id: string;
}> {
    item: T;
    index: number;
    selected: boolean;
    thumbnailUrl: string;
    onItemClick?: (item: T, index: number, event: React__default.MouseEvent) => void;
    onItemDoubleClick?: (item: T, index: number, event: React__default.MouseEvent) => void;
    onSelectionChange?: (action: GridSelectionAction, id: string, index: number) => void;
    onDragStart?: (item: T, index: number, event: React__default.DragEvent) => void;
    onContextMenu?: (item: T, index: number, event: React__default.MouseEvent) => void;
    onCellMouseEnter?: (item: T, index: number, event: React__default.MouseEvent) => void;
    onCellMouseLeave?: (item: T, index: number) => void;
    renderCellOverlay?: (item: T, index: number) => React__default.ReactNode;
    renderCellFooter?: (item: T, index: number) => React__default.ReactNode;
    renderCellTopRight?: (item: T, index: number) => React__default.ReactNode;
}
declare function ImageGridCell<T extends {
    id: string;
}>(props: ImageGridCellProps<T>): react_jsx_runtime.JSX.Element;

interface VirtualizedImageGridProps<T extends {
    id: string;
}> extends ImageGridProps<T> {
    /** TanStack 의 row 추정 높이 (cell aspect-ratio + footer + gap). default 240 */
    estimatedItemHeight?: number;
    /** TanStack overscan rows. default 3 */
    overscan?: number;
    /** 고정 column 수. default 4 (TanStack row-based 가상화 한계 — auto-fit 안 됨) */
    columns?: number;
}
declare function VirtualizedImageGrid<T extends {
    id: string;
}>(props: VirtualizedImageGridProps<T>): react_jsx_runtime.JSX.Element;

declare function StatCard({ label, value, hint, meta, }: {
    label: React__default.ReactNode;
    value: React__default.ReactNode;
    hint?: React__default.ReactNode;
    meta?: React__default.ReactNode;
}): react_jsx_runtime.JSX.Element;
declare const MetricCard: typeof StatCard;

export { type AddDatasetClassOption, AddDatasetModal, type AddDatasetModalProps, type AnnotationBoundingBox, AnnotationOverlay, type AnnotationOverlayBbox, type AnnotationOverlayPoint, type AnnotationOverlayProps, type AnnotationPolygon, AppShell, AppSidebar, type AutoSaveState, AutoSaveStatus, type AutoSaveStatusProps, BarChartCard, ChartContainer, CheckboxGroup, type CheckboxGroupItem, type CheckboxGroupProps, ChipGroup, type ChipGroupItem, type ChipGroupProps, ColorInputRow, type ColorInputRowProps, CommentThread, type CommentThreadProps, DashboardGrid, type DatasetTaskOption, type DatasetTaskType, DateRangeField, type DateRangeFieldProps, DrawingLayer, type DrawingLayerProps, DrawingObject, DrawingPreview, FieldGroup, FieldHint, FieldLabel, FilterBar, type FilterSearchableItem, FilterSearchableList, type FilterSearchableListProps, FilterSection, type FilterSectionProps, FormSection, ImageGrid, ImageGridCell, type ImageGridCellProps, type ImageGridLayout, type ImageGridProps, ImageInspectorCanvas, type ImageInspectorCanvasProps, InspectorLayout, type InspectorPoint, LabelingCanvas, type LabelingCanvasProps, LineChartCard, ListDetailLayout, MediaDialogShell, type MediaDialogShellProps, MetricCard, MobileNavDrawer, PageContent, PageHeader, PageHeaderRow, PagePrimaryHeader, type PagePrimaryHeaderProps, PageSubtitle, PageTitle, PageTitleBlock, Panel, PanelHeader, PanelHint, PanelTitle, PieChartCard, SectionTitle, SettingsRow, type SettingsRowProps, SettingsSection, type SettingsSectionProps, SettingsShell, SidebarFooter, SidebarNav, SidebarSection, SidebarShell, type SidebarShellAction, type SidebarShellItem, type SidebarShellProps, type SortOption, SortPopoverTrigger, type SortPopoverTriggerProps, SplitLayout, StatCard, Toolbar, TopBar, VirtualizedImageGrid, type VirtualizedImageGridProps };
