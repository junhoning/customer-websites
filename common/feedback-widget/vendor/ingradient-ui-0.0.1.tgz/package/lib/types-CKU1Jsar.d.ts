import React__default from 'react';

interface DrawingObject {
    id: string;
    type: 'rect' | 'point';
    x: number;
    y: number;
    w?: number;
    h?: number;
    color?: string;
    label?: string;
    opacity?: number;
}
type DrawingMode = 'cursor' | 'rect' | 'point';
interface DrawingPreview {
    x: number;
    y: number;
    w: number;
    h: number;
}
type DrawingAction = 'create' | 'move' | 'resize' | null;
interface UseDrawingCanvasOptions {
    objects: DrawingObject[];
    mode: DrawingMode;
    minSize?: number;
    handleRadius?: number;
    onObjectsChange: (objects: DrawingObject[]) => void;
    onSelectionChange?: (id: string | null) => void;
    /** Called on mouseup after a drawing action completes (create/move/resize) */
    onComplete?: (objects: DrawingObject[], action: DrawingAction) => void;
    /** Called on right-click with normalized coordinates */
    onContextMenu?: (e: React.MouseEvent, nx: number, ny: number) => void;
    /** If true, empty-space click in cursor mode is ignored (for pan fallback) */
    passThroughEmptyClick?: boolean;
}
declare function useDrawingCanvas({ objects, mode, minSize, handleRadius, onObjectsChange, onSelectionChange, onComplete, onContextMenu, passThroughEmptyClick, }: UseDrawingCanvasOptions): {
    selectedId: string | null;
    drawingPreview: DrawingPreview | null;
    cursor: string;
    bindings: {
        onMouseDown: (e: React.MouseEvent) => void;
        onMouseMove: (_e: React.MouseEvent) => void;
        onMouseUp: () => void;
        onMouseLeave: () => void;
        onContextMenu: (e: React.MouseEvent) => void;
    };
};

type GridSelectionAction = 'toggle' | 'range' | 'single';
/**
 * shift/ctrl/meta 키 감지 → action 분류.
 * caller 는 onSelectionChange 받아 본인 selectedIds 갱신 (range 시 마지막 anchor 기억은 caller 책임).
 */
declare function classifySelectionAction(event: React__default.MouseEvent): GridSelectionAction;

declare const chartAxisTick: {
    readonly fill: "var(--ig-color-text-soft)";
    readonly fontSize: number;
    readonly fontWeight: 500;
};
interface CartesianSeries {
    key: string;
    label: string;
    color?: string;
}
interface PieDatum {
    name: string;
    value: number;
    color?: string;
}

export { type CartesianSeries as C, type DrawingAction as D, type GridSelectionAction as G, type PieDatum as P, type UseDrawingCanvasOptions as U, type DrawingMode as a, type DrawingObject as b, type DrawingPreview as c, chartAxisTick as d, classifySelectionAction as e, useDrawingCanvas as u };
