interface FormatPatternTabItem {
    name?: string | null;
    pattern_label?: string | null;
}
/**
 * Platform 의 sequence pattern 라벨 → 사람이 읽는 형식.
 * - `x_phase_2_of_5` → `X 3/5`
 * - `solid` → `Solid`
 * - `black` → `Black`
 * - 그 외 → item.name 또는 `#{index+1}`
 */
declare function formatPatternTab(item: FormatPatternTabItem, index: number): string;

export { type FormatPatternTabItem as F, formatPatternTab as f };
